import pronto
ont = pronto.Ontology('clo.owl')
print(ont.obo)
