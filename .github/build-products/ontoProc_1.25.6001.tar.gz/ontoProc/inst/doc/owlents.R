## ----getcl,message=FALSE------------------------------------------------------
library(ontoProc)
clont_path = owl2cache(url="http://purl.obolibrary.org/obo/cl.owl")
cle = setup_entities(clont_path)
cle

## ----lkcl---------------------------------------------------------------------
sel = c("CL_0000492", "CL_0001054", "CL_0000236", 
"CL_0000625", "CL_0000576", 
"CL_0000623", "CL_0000451", "CL_0000556")
plot(cle, sel)

## ----gethp--------------------------------------------------------------------
hpont_path = owl2cache(url="http://purl.obolibrary.org/obo/hp.owl")
hpents = setup_entities(hpont_path)
kp = grep("UBER", hpents$clnames, value=TRUE)[21:35]
plot(hpents, kp)

## ----lkta---------------------------------------------------------------------
t(t(table(sapply(strsplit(hpents$clnames, "_"), "[", 1))))

