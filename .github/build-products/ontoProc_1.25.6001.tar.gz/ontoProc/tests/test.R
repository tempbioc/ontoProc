
library(ontoProc)
library(testthat)

test_check("ontoProc")

